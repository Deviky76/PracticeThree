//Reading Data From XLSheet Cell

package Demos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_Data_From_XLCell {

	public static void main(String[] args) throws IOException 
	{

		FileInputStream fi= new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		Workbook wb = new XSSFWorkbook(fi);
		Sheet ws = wb.getSheet("EmpData");
		Row row =ws.getRow(1);
		Cell c1= row.getCell(0);
		Cell c2= row.getCell(1);
		Cell c3 = row.getCell(2);
		Cell c4 = row.getCell(3);
		
		String empno = c1.getStringCellValue();
		String empname = c2.getStringCellValue();
		
		double salary = c3.getNumericCellValue();
		boolean status = c4.getBooleanCellValue();
		
		System.out.println(empno +"   "+empname+"   "+c3+"   "+c4);
		wb.close();
		
	}

}
