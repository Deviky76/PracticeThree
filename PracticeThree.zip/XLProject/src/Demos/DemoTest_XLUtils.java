/*create XLUtils.java
 * 
 * 
 * User Defined Functions
 * 
 * 	.getRowCount()
 * 	.getColumnCount()
 * 	.getStringCellData()
 * 	.getNumericCellData()
 * 	.getNumericCellData()
 * 	.getBooleanellData()
 * 	.setCellData()
 * 	.fillGreenColor()
 * 	.FillRedColor()
 * 
 *  Create XLfile and assign the path to a variable 
 */


package Demos;

import java.io.IOException;

public class DemoTest_XLUtils {

	public static void main(String[] args) throws IOException 
	{
		String datafile ="C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx";
		String datasheet = "EmpData";
		
		//int x = XLUtils.getRowCount("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx", "LoginData");
		//System.out.println(x);
		
		
		//short x =XLUtils.getColumnCount("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx", "EmpData",1);
		//System.out.println(x);
		
		//String x = XLUtils.getStringCellData("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx", "EmpData", 2, 1);
		//System.out.println(x);
		
		
		//Double x = XLUtils.getNumericCellData(datafile, datasheet, 2,2);
		//System.out.println(x);

		
		//Boolean x = XLUtils.getBooleanellData(datafile, datasheet, 1, 3);
		//System.out.println(x);
		
		XLUtils.setCellData(datafile, datasheet, 1, 4, "PASS");
		XLUtils.fillGreenColor(datafile, datasheet, 1, 4);
		
		XLUtils.setCellData(datafile, datasheet, 2, 4, "FAIL");
		XLUtils.fillRedColor(datafile, datasheet, 2, 4);
		
		
		
	}
	
	

}
