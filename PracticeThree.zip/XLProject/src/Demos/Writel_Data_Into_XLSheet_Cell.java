package Demos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Writel_Data_Into_XLSheet_Cell 
{

	public static void main(String[] args) throws IOException 
	{
	
		FileInputStream fi= new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		Workbook wb = new XSSFWorkbook(fi);
		Sheet ws = wb.getSheet("LoginData");
		
		Row row =ws.getRow(1);
		Cell cell =row.createCell(2);
		cell.setCellValue("PASS");
		
		FileOutputStream fo= new FileOutputStream("C:\\Users\\devi\\workspace\\selenium\\testresults.xlsx");
		wb.write(fo);
		wb.close();
		
		
		
	}
}
