//A Script to count number of Rows preset in an Excel Sheet

package Demos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CountNUmberOfRowsInExcelSheet {

	public static void main(String[] args) throws IOException 
	{


		FileInputStream fi = new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		Workbook wb = new XSSFWorkbook(fi);
		Sheet ws1= wb.getSheet("LoginData");
		Sheet ws2 = wb.getSheet("EmpData");
		
		int sheet1_rowcount = ws1.getLastRowNum();
		int sheet2_rowcount =ws2.getLastRowNum();
		
		//System.out.println(fi);
		//System.out.println(wb);
		//System.out.println(ws1);
		System.out.println(sheet1_rowcount);
		//System.out.println(ws2);
		System.out.println(sheet2_rowcount);
		wb.close();
		

	}

}
