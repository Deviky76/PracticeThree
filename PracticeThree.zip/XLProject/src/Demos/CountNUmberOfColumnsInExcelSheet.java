//Counting No. of Columns in an XLSheet Row

package Demos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CountNUmberOfColumnsInExcelSheet 
{

	public static void main(String[] args) throws IOException 
	{
	
		FileInputStream fi =new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		Workbook wb = new XSSFWorkbook(fi);
		Sheet ws= wb.getSheet("LoginData");
		Row row1 = ws.getRow(0);
		Row row2 =ws.getRow(1);
		
		short row1_colcount = row1.getLastCellNum();
		short row2_colcount = row2.getLastCellNum();
		
		System.out.println(row1_colcount);
		System.out.println(row2_colcount);
		wb.close();
		
		
		
	}
}
