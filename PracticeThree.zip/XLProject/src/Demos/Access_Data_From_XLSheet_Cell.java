// Script to handle "Null Pointer Exception" that occurs when No data [resent in XLSheet Cell

package Demos;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Access_Data_From_XLSheet_Cell {

	public static void main(String[] args) throws IOException 
	{
	
		FileInputStream fi= new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		Workbook wb = new XSSFWorkbook(fi);
		Sheet ws = wb.getSheet("LoginData");
		
		Row row =ws.getRow(1);
		Cell cell= row.getCell(2);
		
		String data;
		try 
		{
		
			data= cell.getStringCellValue();
			System.out.println(data);
			
		} catch (Exception e) {
			System.out.println("No data found!");
		}
		

	}

}
