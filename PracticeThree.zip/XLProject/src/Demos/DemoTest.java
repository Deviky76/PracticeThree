//Using FileInputStream and FileOutputStream

package Demos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DemoTest {

	public static void main(String[] args) throws IOException 
	{
	
		FileInputStream fi1 = new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		FileInputStream fi2 = new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\SAMPLE.xlsx");
		
		Workbook wb1 = new  XSSFWorkbook(fi1);
		Workbook wb2 = new XSSFWorkbook(fi2);
		
		wb1.createSheet("Demosheet2");
		wb2.createSheet("Sample Sheet2");
		
		
		FileOutputStream fo1 = new FileOutputStream("C:\\Users\\devi\\workspace\\selenium\\Result.xlsx");
		wb1.write(fo1);
		
		FileOutputStream fo2 = new FileOutputStream("C:\\Users\\devi\\workspace\\selenium\\SAMPLE.xlsx");
		wb2.write(fo2);
		
		wb1.close();
		wb2.close();
	}

}
