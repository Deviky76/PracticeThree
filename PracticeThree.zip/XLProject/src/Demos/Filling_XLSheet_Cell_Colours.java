// Filling XLSheet Colour with Green

package Demos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Filling_XLSheet_Cell_Colours {

	public static void main(String[] args) throws IOException 
	{


		FileInputStream fi= new FileInputStream("C:\\Users\\devi\\workspace\\selenium\\testdata.xlsx");
		Workbook wb = new XSSFWorkbook(fi);
		Sheet ws = wb.getSheet("LoginData");
		
		Row row =ws.getRow(1);
		Cell cell= row.createCell(2);
		
		//cell.setCellValue("PASS");
		cell.setCellValue("FAIL");
		
		//CellStyle passstyle =wb.createCellStyle();
		CellStyle failstyle =wb.createCellStyle();
		
		//passstyle.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
		failstyle.setFillForegroundColor(IndexedColors.RED.getIndex());
		
		//passstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		failstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		
		//cell.setCellStyle(passstyle);
		cell.setCellStyle(failstyle);
		
		
		FileOutputStream fo = new FileOutputStream("C:\\Users\\devi\\workspace\\selenium\\testrresult.xlsx");
		wb.write(fo);
		wb.close();
		
		
		
		

	}

}
