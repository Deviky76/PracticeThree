package selenium_practice;

public class Functions_Demo 
{

String url;
	
	public void f1()
	{
		url="http://amazon.com";
		System.out.println(url);
	}
	public void f2()
	{
		System.out.println(url);
	}
}
