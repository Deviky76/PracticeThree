package java_Practice;

public class Factorial 
{

	public static void main(String[] args) 
	{
		 int i,fact=1;
		 for(i=5;i>=1;i--)
		 { 
			 fact=fact*i;
			 System.out.println(i+"*"+fact);
		 }
		 System.out.println("Factorial value is: "+fact);
	}

}
