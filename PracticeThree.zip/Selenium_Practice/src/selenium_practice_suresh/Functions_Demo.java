package selenium_practice_suresh;

public class Functions_Demo 
{

	String url;
	
	public void f1()
	{
		url="http://amazon.com";
		System.out.println(url);
	}
}
