package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Assert_False 
{

	@Test
	public void test1()
	{
		
		boolean actres = false;
		Assert.assertFalse(actres);
		
	}
	
	@Test
	public void test2()
	{
		boolean actres = true;
		Assert.assertFalse(actres);
	}
}
