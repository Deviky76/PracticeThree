package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Assert_Equals 
{
	@Test
	public void test1()
	{
		
		String exptitle, acttitle;
		exptitle ="google";
		acttitle ="google";
		
		Assert.assertEquals(exptitle, acttitle);
		
		//System.out.println(exptitle + "    "+acttitle);
		
	}
	
	@Test
	public void test2()
	{
		
		String exptitle, acttitle;
		exptitle = "google";
		acttitle = "gmail";
		
		Assert.assertEquals(exptitle, acttitle);
		
	}
	
}
