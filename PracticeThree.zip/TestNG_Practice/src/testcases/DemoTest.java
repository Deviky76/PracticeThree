package testcases;

import org.testng.annotations.Test;

public class DemoTest 
{

	@Test(priority=0)
	public void launchApp()
	{
		
		System.out.println("Launch APP");
		
	}
	
	@Test(priority=1)
	public void adminLogin()
	{
		
		System.out.println("Admin Login");
		
	}
	
	
	
	
}
