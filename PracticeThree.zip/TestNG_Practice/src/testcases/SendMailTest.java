package testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import utils.AppUtils;

public class SendMailTest extends AppUtils
{

	@Parameters({"mailid","sub"})
	@Test
	public void checkSendMail(String tomail, String sub)
	{
		
		System.out.println("Mail Send To:   " + tomail + "   with Subject:  "+sub);
		
		
	}
	
	
}
