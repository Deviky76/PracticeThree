package testcases;

import org.testng.annotations.Test;

import utils.AppUtils;

public class ReceiveMailTest extends AppUtils
{
	
	@Test 
	public void checkReceiveMail()
	{
		
		System.out.println("This is Receive Mail Testcase");
	}

}
