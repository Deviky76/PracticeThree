package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Assert_True 
{

	@Test
	public void test1()
	{
		
		boolean actres = true;
		Assert.assertTrue(actres);
		
	}
	
	@Test
	public void test2()
	{
		boolean actres = false;
		Assert.assertTrue(actres);
	}
	
	
	
	
	
}
